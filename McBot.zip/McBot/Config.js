module.exports = {

    Config: function(){
        this.domain = 'www.myserver.com';
        this.port = 25565;
        this.botToken = '';

        return this;
    }

};